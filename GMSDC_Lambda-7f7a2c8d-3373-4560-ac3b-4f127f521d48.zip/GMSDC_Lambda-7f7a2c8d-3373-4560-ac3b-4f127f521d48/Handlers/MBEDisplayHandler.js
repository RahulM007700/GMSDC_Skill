const helper = require('./Helper')
const eventsHandler = require('./EventsHandler');

const MBEDisplayHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'TellMeMoreIntent';
    },
    async handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        let template = require('../Template/MBETemplate.json');
        var corporation = slots.mbes.value.toLowerCase();
        let data = bodyData(result);

        //var month = slots.month.value.toLowerCase();
        return helper.getMBEData(corporation).then((result) => {
            console.log(result);
            if(result[0].Video == undefined){
                const speechText = `Here is description about ${result[0].MBEs}`;
                return handlerInput.responseBuilder
                .speak(speechText)
                .reprompt("Sorry, I did not understand that. Please say again")
                .addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.0',
                    token: "MBEToken",
                    document: template,
                    datasources: data
                })
                .getResponse();
            }else if(result[0].Picture == undefined){
                return handlerInput.responseBuilder
                .speak(speechText)
                .addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.0',
                    token: "MBEToken",
                    document: template,
                    datasources: data
                })
                .getResponse();
            }else{
                const speechText = `Here is description about ${result[0].MBEs}. The MBE or corporation also includes a video, would you like to watch the video`;
                return handlerInput.responseBuilder
                .speak(speechText)
                .addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.0',
                    token: "MBEToken",
                    document: template,
                    datasources: data
                })
                .getResponse();
            }
           })
           .catch((err) => {
               const speechText = `Sorry there is no corporation with that name`;
               console.log("Error: ", JSON.stringify(err, null, 2));
               return handlerInput.responseBuilder.speak(speechText).getResponse();
           }) 
    }
  };

function bodyData(result){
    return {
        "bodyTemplate2Data": {
            "type": "object",
            "objectId": "bt2Sample",
            "backgroundImage": {
                "contentDescription": null,
                "smallSourceUrl": null,
                "largeSourceUrl": null,
                "sources": [
                    {
                        "url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
                        "size": "small",
                        "widthPixels": 0,
                        "heightPixels": 0
                    },
                    {
                        "url": "https://d2o906d8ln7ui1.cloudfront.net/images/BT2_Background.png",
                        "size": "large",
                        "widthPixels": 0,
                        "heightPixels": 0
                    }
                ]
            },
            "title": result[0].MBEs.charAt(0).toUpperCase() + result[0].MBEs.slice(1),
            "image": {
                "contentDescription": null,
                "smallSourceUrl": null,
                "largeSourceUrl": null,
                "sources": [
                    {
                        "url": result[0].Picture,
                        "size": "small",
                        "widthPixels": 0,
                        "heightPixels": 0
                    },
                    {
                        "url": "https://d2o906d8ln7ui1.cloudfront.net/images/details_01.png",
                        "size": "large",
                        "widthPixels": 0,
                        "heightPixels": 0
                    }
                ]
            },
            "textContent": {
                "primaryText": {
                    "type": "PlainText",
                    "text": result[0].Description
                }
            },
            "hintText": "Try, \"Alexa, main menu\""
        }
    }
}

module.exports = MBEDisplayHandler;