var AWS = require("aws-sdk");

var dbHelper = function () { };
var docClient = new AWS.DynamoDB.DocumentClient();

dbHelper.prototype.getData = (month) => {
    return new Promise((resolve, reject) => {
        var params = {
            TableName: "GMSDC",
            KeyConditionExpression: "#m = :mmmm",
            ExpressionAttributeNames: {
                "#m": "Month"
            },
            ExpressionAttributeValues: {
                ":mmmm": month
            }
        };
        docClient.query(params, (err, data) => {
            if (err) {
                console.error("Database Reading Error: ", JSON.stringify(err, null, 2));
                return reject(JSON.stringify(err, null, 2))
            } 
            console.log(month);
            console.log("Query Succeeded:", JSON.stringify(data, null, 2));
            resolve(data.Items)
            
        })
    });
}

dbHelper.prototype.getEvent = (month, date) => {
    return new Promise((resolve, reject) => {
        var params = {
            TableName: "GMSDC",
            KeyConditionExpression: "#m = :mmmm and #d = :dd",
            ExpressionAttributeNames: {
                "#m": "Month",
                "#d": "Date"
            },
            ExpressionAttributeValues: {
                ":mmmm": month,
                ":dd": date
            }
        };
        docClient.query(params, (err, data) => {
            if(err){
                console.error("Database Reading Error: ", JSON.stringify(err, null, 2));
                return reject(JSON.stringify(err, null, 2))
            }

            console.log("Query Succeeded:", JSON.stringify(data, null, 2));
            resolve(data.Items);
        })
    })
}

dbHelper.prototype.getMBEData = (name) => {
    console.log(name)
    return new Promise((resolve, reject) => {
        var params = {
            TableName: "MBEs_and_Corporations",
            KeyConditionExpression: "#n = :nnnn",
            ExpressionAttributeNames: {
                "#n": "MBEs"
            },
            ExpressionAttributeValues: {
                ":nnnn": name
            }
        };
        docClient.query(params, (err, data) => {
            if (err) {
                console.error("Database Reading Error: ", JSON.stringify(err, null, 2));
                return reject(JSON.stringify(err, null, 2))
            } 
            console.log(name);
            console.log("Query Succeeded:", JSON.stringify(data, null, 2));
            resolve(data.Items)
            
        })
    });
}


module.exports = new dbHelper();