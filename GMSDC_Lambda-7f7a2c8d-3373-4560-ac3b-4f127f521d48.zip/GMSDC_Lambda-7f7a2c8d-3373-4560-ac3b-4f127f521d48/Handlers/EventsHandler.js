const months = require('../Data/months')

const EventsHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'MonthsIntent';
    },
    handle(handlerInput) {
       const slots = handlerInput.requestEnvelope.request.intent.slots;

       const attributes = handlerInput.attributesManager.getSessionAttributes();
       attributes.month = slots.calendar.value;
       attributes.lastVisit = 'eventsToken';
       handlerInput.attributesManager.setSessionAttributes(attributes);

       let template = require('../Template/displayMonth.json');
       let result = months[slots.calendar.value.toLowerCase()]
       //return helper.getData(months3).then((result) => {
        console.log(result);
        let data = createData(result);
        const speechText = "Here are the events in " + result[0].Month;
        return handlerInput.responseBuilder
          .speak(speechText)
          .addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            version: '1.0',
            token: "eventsToken",
            document: template,
            datasources: data
          })
          .getResponse();
    //    })
    //    .catch((err) => {
    //        const speechText = "Sorry an error occured";
    //        console.log("Error: " + err)
    //        return handlerInput.responseBuilder.speak(speechText).getResponse();
    //    })     
    }
  };

  function createData(result){
    let data = [];
    for(var i = 0; i < result.length; i++){
        data.push({
                    "listItemIdentifier": result[i].Date,
                    "ordinalNumber": result[i].Date,
                    "textContent": {
                        "primaryText": {
                            "type": "PlainText",
                            "text": result[i].Event
                        },
                        "secondaryText": {
                            "type": "PlainText",
                            "text": result[i].Time
                        },
                            "tertiaryText": {
                                "type": "PlainText",
                                "text": result[i].Day
                        }
                    },
                            "token": result[i].ordinal
                });
    }
    return {
            "listTemplate1Metadata": {
            "type": "object",
            "objectId": "lt1Metadata",
            "backgroundImage": {
                "contentDescription": null,
                "smallSourceUrl": null,
                "largeSourceUrl": null,
                "sources": [
                            {
                                "url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
                                "size": "small",
                                "widthPixels": 0,
                                "heightPixels": 0
                            },
                            {
                                "url": "https://d2o906d8ln7ui1.cloudfront.net/images/LT1_Background.png",
                                "size": "large",
                                "widthPixels": 0,
                                "heightPixels": 0
                            }
                            ]
                        },
                        "title": result[0].Month.charAt(0).toUpperCase() + result[0].Month.slice(1) + " Events"
                    },
                    "listTemplate1ListData": {
                        "type": "list",
                        "listId": "lt1Sample",
                        "totalNumberOfItems": 10,
                        "listPage": {
                            "listItems": data
                    }
                }
            }
  }

  function supportsAPL(handlerInput) {
    const interfaces = handlerInput.requestEnvelope.context.System.device.supportedInterfaces;
    const aplInterface = interfaces['Alexa.Presentation.APL'];
    return aplInterface != null && aplInterface !== undefined;
  }
  

module.exports = {EventsHandler, createData, supportsAPL};