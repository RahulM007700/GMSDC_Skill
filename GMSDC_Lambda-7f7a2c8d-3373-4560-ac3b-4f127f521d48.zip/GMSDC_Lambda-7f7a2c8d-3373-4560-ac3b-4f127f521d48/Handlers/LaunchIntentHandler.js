const eventsHandler = require('./EventsHandler');

const LaunchIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === "LaunchRequest";
  },
  handle(handlerInput) {
     let template = require('../Template/launch.json');
     let data = require('../Data/launch.json');
    
    const speechText = "Welcome to GMSDC. Here you can choose to see the new MBE's and Corporation Members videos, view the calendar of upcoming events, and frequently asked questions and answers";

    if(!eventsHandler.supportsAPL(handlerInput)){
      return handlerInput.responseBuilder.speak(speechText).getResponse();
    }

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt("Sorry, I did not understand that. Please say again")
      .addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        version: '1.0',
        token: "launchToken",
        document: template,
        datasources: data
      })
      .getResponse();
      
  }
};

module.exports = LaunchIntentHandler;