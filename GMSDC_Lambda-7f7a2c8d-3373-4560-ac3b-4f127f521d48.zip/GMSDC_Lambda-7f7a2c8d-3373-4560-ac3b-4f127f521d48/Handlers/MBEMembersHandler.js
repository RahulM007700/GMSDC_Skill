const helper = require('./Helper')

const MBEMemberHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'MonthsIntent';
    },
    handle(handlerInput) {
       const slots = handlerInput.requestEnvelope.request.intent.slots;
       let template = require('../Template/displayMonth.json');
       let result = months[slots.calendar.value.toLowerCase()]
       return helper.getEvent(month, date).then((result) => {
        console.log(result);
        let data = createData(result);
        const speechText = "Here are the events in " + result[0].Month;
        return handlerInput.responseBuilder
          .speak(speechText)
          .addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            version: '1.0',
            token: "MBENamesToken",
            document: template,
            datasources: data
          })
          .getResponse();
       })
       .catch((err) => {
           const speechText = "Sorry an error occured";
           console.log("Error: " + err)
           return handlerInput.responseBuilder.speak(speechText).getResponse();
       })     
    }
  };