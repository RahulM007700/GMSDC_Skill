const answers = require('../Data/Answers.js')

const AnswerHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'AnswerIntent';
    },
    handle(handlerInput) {
       const slots = handlerInput.requestEnvelope.request.intent.slots;
       let template = require('../Template/AnswerTemplate.json');
	   let value = slots.categories.value.toLowerCase();
       console.log("The result is " + value);
	   console.log("The answer value is " + answers[0].Slot);
       let data = createData(value);
       const speechText = "Here is more information about " + slots.categories.value;
       return handlerInput.responseBuilder
         .speak(speechText)
         .addDirective({
           type: 'Alexa.Presentation.APL.RenderDocument',
           version: '1.0',
           token: "answerToken",
           document: template,
           datasources: data
         })
         .getResponse();
    }
  };
  
 
function createData(value){
	let i = 0;
	for(i = 0; i < answers.length; i++) {
		if (answers[i].Slot === value) {
			return {
				"bodyTemplate1Data": {
				"type": "object",
				"objectId": "bt1Sample",
				"backgroundImage": {
					"contentDescription": null,
					"smallSourceUrl": null,
					"largeSourceUrl": null,
					"sources": [
						{
							"url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
							"size": "small",
							"widthPixels": 0,
							"heightPixels": 0
						},
						{
							"url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
							"size": "large",
							"widthPixels": 0,
							"heightPixels": 0
						}
					]
				},
				"title": answers[i].Category,
				"textContent": {
					"primaryText": {
						"type": "PlainText",
						"text": answers[i].Data,
					}
				},
				"logoUrl": "" 
				}
			}
		}
	}
    return {"bodyTemplate1Data": {
        "type": "object",
        "objectId": "bt1Sample",
        "backgroundImage": {
            "contentDescription": null,
            "smallSourceUrl": null,
            "largeSourceUrl": null,
            "sources": [
                {
                    "url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
                    "size": "small",
                    "widthPixels": 0,
                    "heightPixels": 0
                },
                {
                    "url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
                    "size": "large",
                    "widthPixels": 0,
                    "heightPixels": 0
                }
            ]
        },
        "title": "Yes",
        "textContent": {
            "primaryText": {
                "type": "PlainText",
                "text": "Yes",
            }
        },
	"logoUrl": "" }
    }

}


module.exports = AnswerHandler;
