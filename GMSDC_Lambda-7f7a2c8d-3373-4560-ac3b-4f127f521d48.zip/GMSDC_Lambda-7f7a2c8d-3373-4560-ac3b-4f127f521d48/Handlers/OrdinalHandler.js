var eventsHandler = require('./EventsHandler');
var months = require('../Data/months')
const MonthsHandler = require('./MonthsIntentHandler');


var ordinals = {
    "1": "january",
    "2": "february",
    "3": "march",
    "4": "april",
    "5": "may",
    "6": "june",
    "7": "july",
    "8": "august",
    "9": "september",
    "10": "october",
    "11": "november",
    "12": "december"
}

const OrdinalHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'OrdinalIntent';
    },
    handle(handlerInput){
        const token = handlerInput.requestEnvelope.context['Alexa.Presentation.APL'].token;
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        let ordinal = slots.number.value;
        if(token == 'launchToken' && ordinal == '1'){
            return MonthsHandler.handle(handlerInput);
        }else{
            let template = require('../Template/displayMonth.json');
            let result = months[ordinals[ordinal]]
            console.log(result);
            let data = eventsHandler.createData(result);
            const speechText = "Here are the events in " + result[0].Month;
            return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt("Sorry, I did not understand that. Please say again")
            .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.0',
                token: "eventsToken",
                document: template,
                datasources: data
            })
            .getResponse();
        }
    }
}

module.exports = OrdinalHandler;