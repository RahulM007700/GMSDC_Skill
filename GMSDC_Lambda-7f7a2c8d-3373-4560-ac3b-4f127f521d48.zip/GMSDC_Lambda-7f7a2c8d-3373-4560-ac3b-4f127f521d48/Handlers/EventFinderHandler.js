const helper = require('./Helper')
const eventsHandler = require('./EventsHandler');
const months = require('../Data/months')

const EventFinderHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'EventIntent' && 
        handlerInput.requestEnvelope.request.intent.slots.month.value;
    },
    async handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
       let template = require('../Template/event.json');
        
        var date = slots.date.value;
        var month = slots.month.value.toLowerCase();

        return helper.getEvent(month, date).then((result) => {
            console.log(result);
            let data = bodyData(result);
            const speechText = `${result[0].Event} is taking place on ${result[0].Month} ${result[0].Date}`;
            // speechText += result.map(x => x.Month).join(", ");
            if(!eventsHandler.supportsAPL(handlerInput)){
                return handlerInput.responseBuilder.speak(speechText).reprompt("Sorry, I did not understand that. Please say again").getResponse();
            }
            return handlerInput.responseBuilder
              .speak(speechText)
              .reprompt("Sorry, I did not understand that. Please say again")
               .addDirective({
                 type: 'Alexa.Presentation.APL.RenderDocument',
                 version: '1.0',
                token: "eventsFinderToken",
                document: template,
                datasources: data
              })
              .getResponse();
           })
           .catch((err) => {
               const speechText = `There are no events on that day`;
               console.log("Error: ", JSON.stringify(err, null, 2));
               return handlerInput.responseBuilder.speak(speechText).getResponse();
           }) 
       
        
    }
  };

  function bodyData(result){
      return {
        "bodyTemplate1Data": {
            "type": "object",
            "objectId": "bt1Sample",
            "backgroundImage": {
                "contentDescription": null,
                "smallSourceUrl": null,
                "largeSourceUrl": null,
                "sources": [
                    {
                        "url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
                        "size": "small",
                        "widthPixels": 0,
                        "heightPixels": 0
                    },
                    {
                        "url": "https://d2o906d8ln7ui1.cloudfront.net/images/BT1_Background.png",
                        "size": "large",
                        "widthPixels": 0,
                        "heightPixels": 0
                    }
                ]
            },
            "textContent": {
                "primaryText": {
                    "type": "PlainText",
                    "text": result[0].Event
                },
                "secondaryText": {
                    "type": "PlainText",
                    "text": `${result[0].Month.charAt(0).toUpperCase() + result[0].Month.slice(1)} ${result[0].Date}<br>${result[0].Time}<br>${result[0].Location}<br>${result[0].Description}`
                }
            },
        }
    }
  }


  module.exports = EventFinderHandler;