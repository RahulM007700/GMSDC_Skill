const MonthsHandler = require('./MonthsIntentHandler');

const GobackHandler = {
    canHandle(handlerInput){
        return handlerInput.requestEnvelope.request.intent.name == 'AMAZON.PreviousIntent';
    },
    handle(handlerInput){
        const token = handlerInput.requestEnvelope.context['Alexa.Presentation.APL'].token;
        const attributes = handlerInput.attributesManager.getSessionAttributes();

        if(token == 'monthsToken'){
            let template = require('../Template/launch.json');
            let data = require('../Data/launch.json');
        
            const speechText = "";
            return handlerInput.responseBuilder
                .speak(speechText)
                .reprompt("Sorry, I did not understand that. Please say again")
                .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.0',
                token: "launchToken",
                document: template,
                datasources: data
                })
                .getResponse();    
        }    
        if(token == 'eventsToken' || attributes.lastVisit == 'eventsToken')
            return MonthsHandler.handle(handlerInput);
        if(token == 'eventsDescriptionToken'){
            let template = require('../Template/launch.json');
            let data = require('../Data/launch.json');
            
            const speechText = "Welcome to GMSDC. Here you can choose to see the new MBE's and Corporation Members videos, view the calendar of upcoming events, and frequently asked questions and answers";

            return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt("Sorry, I did not understand that. Please say again")
            .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.0',
                token: "launchToken",
                document: template,
                datasources: data
            })
      .getResponse();
        }
        
        return handlerInput.responseBuilder
        .speak("Please say main menu to go to the main menu")
        .reprompt("Sorry, I didn't get that. Please say again")
        .getResponse();
    }
}

module.exports = GobackHandler;