const months = require('../Data/months')

const EventDescriptionHandler = {
    canHandle(handlerInput){
        return handlerInput.requestEnvelope.request.intent.name == 'EventIntent' &&
        handlerInput.requestEnvelope.request.intent.slots.date.value;
    },
    handle(handlerInput){
        const slots = handlerInput.requestEnvelope.request.intent.slots;
       let template = require('../Template/event.json');
        
        var date = slots.date.value;
        const attributes = handlerInput.attributesManager.getSessionAttributes();
        const token = attributes.month.toLowerCase();
        let result = months[token];

        console.log(result);
        console.log(result.length);

        for(var j = 0; j < months[token].length; j++){
            if(months[token][j].Date == date){
                const speechText = `${months[token][j].Event} is taking place on ${months[token][j].Month} ${months[token][j].Date}`;
                let data = eventDescription(months[token][j]);

                return handlerInput.responseBuilder
                .speak(speechText)
                .addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.0',
                    token: "eventsFinderToken",
                    document: template,
                    datasources: data
                })
                .getResponse();
            }
        }
        return handlerInput.responseBuilder
        .speak("There are no events taking place on that day")
        .getResponse();    
    }
}

  function eventDescription(result){
    return {
        "bodyTemplate1Data": {
            "type": "object",
            "objectId": "bt1Sample",
            "backgroundImage": {
                "contentDescription": null,
                "smallSourceUrl": null,
                "largeSourceUrl": null,
                "sources": [
                    {
                        "url": "https://gmsdc.s3.amazonaws.com/InfosmartGMSDC.png",
                        "size": "small",
                        "widthPixels": 0,
                        "heightPixels": 0
                    },
                    {
                        "url": "https://d2o906d8ln7ui1.cloudfront.net/images/BT1_Background.png",
                        "size": "large",
                        "widthPixels": 0,
                        "heightPixels": 0
                    }
                ]
            },
            "textContent": {
                "primaryText": {
                    "type": "PlainText",
                    "text": result.Event
                },
                "secondaryText": {
                    "type": "PlainText",
                    "text": `${result.Month.charAt(0).toUpperCase() + result.Month.slice(1)} ${result.Date}<br>${result.Time}<br>${result.Location}<br>${result.Description}`
                }
            },
        }
    }
  }

  module.exports = EventDescriptionHandler;