//var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'November', 'December'];
var eventsHandler = require('./EventsHandler')

const MonthsHandler = {
    canHandle(handlerInput){
        return handlerInput.requestEnvelope.request.intent.name == 'MonthsIntent' &&
        handlerInput.requestEnvelope.request.intent.slots.calendar.value.toLowerCase() == 'calendar';
    },
    handle(handlerInput){
        let template1 = require('../Template/months.json');
        let data1 = require('../Data/months.json');
        
        const speechText = "Please specify a month";

        if(!eventsHandler.supportsAPL(handlerInput)){
            return handlerInput.responseBuilder.speak(speechText).reprompt(speechText).getResponse();
          }  

        return handlerInput.responseBuilder
           .speak(speechText)
          .reprompt(speechText)
          .addDirective({
              type: 'Alexa.Presentation.APL.RenderDocument',
              token: 'monthsToken',
              version: '1.0',
              document: template1,
              datasources: data1
          })
         .getResponse();
    }
};

module.exports = MonthsHandler;
