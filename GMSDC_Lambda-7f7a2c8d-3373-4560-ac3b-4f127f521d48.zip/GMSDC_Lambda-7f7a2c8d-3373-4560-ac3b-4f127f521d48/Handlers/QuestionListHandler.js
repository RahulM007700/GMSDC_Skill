const QuestionListHandler = {
	canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.intent.name == 'QuestionIntent';
    },
	handle(handlerInput) {
		const slots = handlerInput.requestEnvelope.request.intent.slots;
		let template = require('../Template/QuestionListTemplate.json');
		let data = require('../Data/QuestionList.json');
    
		const speechText = "What would you like to know more about?";
		return handlerInput.responseBuilder
			.speak(speechText)
			.reprompt("Sorry, I did not understand that. Please say again")
			.addDirective({
				type: 'Alexa.Presentation.APL.RenderDocument',
				version: '1.0',
				token: "questionListToken",
				document: template,
				datasources: data
			})
			.getResponse();
      
  
	}
};

module.exports = QuestionListHandler;