const eventsHandler = require('./EventsHandler');

const MainMenuIntent = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.intent.name === "MainMenuIntent";
  },
  handle(handlerInput) {
     let template = require('../Template/launch.json');
     let data = require('../Data/launch.json');
    
    const speechText = "";

    if(!eventsHandler.supportsAPL(handlerInput)){
      return handlerInput.responseBuilder.speak(speechText).getResponse();
    }

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt("Sorry, I did not understand that. Please say again")
      .addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        version: '1.0',
        token: "launchToken",
        document: template,
        datasources: data
      })
      .getResponse();
      
  }
};

module.exports = MainMenuIntent;