const AWS = require('aws-sdk');

const csv = require('csvtojson');
const S3 = new AWS.S3();
const params = {
  Bucket: 'gmsdc',
  Key: 'test.csv'
};

async function JSONFile() {
  const stream = S3.getObject(params).createReadStream();
  const json = await csv().fromStream(stream);
  console.log(json);
  return json;
};

var january = []
var february = []
var march = []
var april = []
var may = []
var june = []
var july = []
var august = []
var september = []
var october = []
var november = []
var december = []

JSONFile().then(function(result) {
    console.log(result)
    for(var i = 0; i < result.length; i++){
        if(result[i].Month == "january")
            january.push(result[i])
        if(result[i].Month == "february")
            february.push(result[i])
        if(result[i].Month == "march")
            march.push(result[i])
        if(result[i].Month == "april")
            april.push(result[i])
        if(result[i].Month == "may")
            may.push(result[i])
        if(result[i].Month == "june")
            june.push(result[i])
        if(result[i].Month == "july")
            july.push(result[i])
        if(result[i].Month == "august")
            august.push(result[i])
        if(result[i].Month == "september")
            september.push(result[i])
        if(result[i].Month == "october")
            october.push(result[i])
        if(result[i].Month == "november")
            november.push(result[i])
        if(result[i].Month == "december")
            december.push(result[i])    
    }
});

// var september = [
//     {
//         "Month": "september",
//         "Day": "Sun",
//         "ordinal": "9",
//         "Date": "1",
//         "Event": "First day of september"
//     },
//     {
//         "Month": "september",
//         "ordinal": "9",
//         "Date": "7",
//         "Day": "Mon",
//         "Event": "Labor Day"
//     }
// ]

// var october = [
//     {
//         "Month": "october",
//         "Date": "31",
//         "ordinal": "10",
//         "Day": "Thu",
//         "Event": "Halloween"
//     }
// ]

// var november = [
//     {
//         "Month": "november",
//         "Day": "Fri",
//         "ordinal": "11",
//         "Date": "24",
//         "Event": "Thanksgiving"
//     }
// ]

// var may = [
//     {
//         "Month": "may",
//         "Date": "5",
//         "ordinal": "5",
//         "Day": "Sun",
//         "Event": "Cinco de Mayo"
//     }
// ]

// var march = [
//     {
//         "Month": "march",
//         "Date": "14",
//         "ordinal": "3",
//         "Day": "Mon",
//         "Event": "Pi Day"
//     },
//     {
//         "Month": "march",
//         "Date": "7",
//         "ordinal": "3",
//         "Day": "Tue",
//         "Event": "Birthday"
//     }
// ]

// var june = [
//     {
//         "Month": "june",
//         "Date": "10",
//         "ordinal": "6",
//         "Day": "Thu",
//         "Event": "Birthday"        
//     }
// ]

// var july = [
//     {
//         "Month": "july",
//         "Date": "12",
//         "ordinal": "7",
//         "Day": "Sat",
//         "Event": "Birthday"
//     }
// ]

// var january = [
//     {
//         "Month": "january",
//         "Day": "Wed",
//         "ordinal": "1",
//         "Date": "1",
//         "Event": "New Years"
//     }
// ]

// var february = [
//     {
//         "Month": "february",
//         "Date": "14",
//         "ordinal": "2",
//         "Day": "Mon",
//         "Event": "Valentine's Day"
//     }
// ]

// var december = [
//     {
//         "Month": "december",
//         "Date": "25",
//         "ordinal": "12",
//         "Day": "Sun",
//         "Event": "Christmas"
//     },
//     {
//         "Month": "december",
//         "Date": "31",
//         "ordinal": "12",
//         "Day": "Tue",
//         "Event": "New Years"
//     }
// ]

// var august = [
//     {
//         "Month": "august",
//         "Date": "20",
//         "ordinal": "8",
//         "Day": "Sun",
//         "Event": "Birthday"   
//     }
// ]

// var april = [
//     {
//         "Month": "april",
//         "Date": "7",
//         "ordinal": "4",
//         "Day": "Sat",
//         "Event": "Birthday"
//     }
// ]

module.exports = {january, february, march, april, may, june, july, august, september, october, november, december};

