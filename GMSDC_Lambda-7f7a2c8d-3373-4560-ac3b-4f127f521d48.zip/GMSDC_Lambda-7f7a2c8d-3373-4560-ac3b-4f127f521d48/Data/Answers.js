var overview = [{
	"Slot": "overview",
	"Category": "Overview",
	"Token": 0,
	"Data": "1. Review certification criteria below to ensure that your business qualifies.\n2. Gather required documentation.\n3. Documentation requirements are listed directly below.\n4. Complete the online registration form in full. You’ll have as long as you need to complete the application and can save each session as you go.\n5. Application fee must be paid online via credit card.\n6. Upload the required documentation via the online certification/recertification application.\n7. Schedule site visit and interview. These will be performed by a NMSDC Certification Specialist.\n8. Wait for final approval from both Committee and Board Members."
}]
var criteria = [{
	"Slot": "criteria",
	"Category": "Criteria",
	"Token": 1,
	"Data": "To become a Certified Minority Business Enterprise (MBE), your business must meet the following requirements. Both current and historical facts are considered in determining ownership qualifications and participation in the management and operations of the company.\n\tUnited States citizens.\n\tMinority businesses must be at least 51% minority-owned operated and controlled.\n\tFor the purposes of NMSDC’s program, a minority group member is an individual who is at least 25% Asian, Black, Hispanic or Native American. Minority eligibility is established via a combination of screenings, interviews and site visits. Ownership, in the case of a publicly-owned business, means that at least 51% of the stock is owned by one or more minority group members.\n\tMust be a profit enterprise and physically located in the U. S. or its trust territories.\n\tManagement and daily operations must be exercised by the minority ownership member(s)."
}]
var documentation = [{
	"Slot": "documentation",
	"Category": "Documentation",
	"Token": 2,
	"Data": "(documents will vary by business types – below is a sample for corporations)(documents will vary by business types – below is a sample for corporations)\n\tThe History of Business\n\tCertificate of Incorporation\n\tArticles of Incorporation\n\tStock Certificates and Stock Ledger\n\tMinutes to Board of Director’s meetings as well as Shareholder’s meetings\n\tBylaws (executed and attested) and Amendments (if applicable)\n\tAll agreement(s) pertaining to ownership, operation, and control of the business\n\tBusiness cards that list appropriate corporate titles, copies of resumes, copy of driver’s licenses and proof of US Citizenship (Birth certificates or U.S. Passports only) for all Principals\n\tCorporate Bank Resolution Agreement(s) to include Bank Signature Card(s)\n\tBusiness Lease Agreement(s) (and Security Deeds if home-based)\n\tProof of general liability insurance and in some cases bonding\n\tCopies of the businesses’ cancelled checksThe History of Business\n\tCertificate of Incorporation\n\tArticles of Incorporation\n\tStock Certificates and Stock Ledger\n\tMinutes to Board of Director’s meetings as well as Shareholder’s meetings\n\tBylaws (executed and attested) and Amendments (if applicable)\n\tAll agreement(s) pertaining to ownership, operation, and control of the business\n\tBusiness cards that list appropriate corporate titles, copies of resumes, copy of driver’s licenses and proof of US Citizenship (Birth certificates or U.S. Passports only) for all Principals\n\tCorporate Bank Resolution Agreement(s) to include Bank Signature Card(s)\n\tBusiness Lease Agreement(s) (and Security Deeds if home-based)\n\tProof of general liability insurance and in some cases bonding\n\tCopies of the businesses’ cancelled checks"
}]
var appproces = [{
	"Slot": "appproces",
	"Category": "Application Process",
	"Token": 3,
	"Data": "The Certification process can take up to 90 days.\nBefore you begin the online application, you will need to register on our site.\nWhen completing the application, feel free to take as long as needed.\nYour information will be saved for your next session and is completely confidential.\nThe processing of your application will begin when payment is received.\nApplication and documents are reviewed for completeness.\nThe Certification Committee meets regularly to review applications for MBE Certification.\nThe Certification Committee must approve the application before it can be submitted to the Board for final approval.\nThe Board will review the Certification Committee’s recommendation and make the final decision.\nIf your application is approved, you will be notified via e-mail and postal mail.\nIf the Board rejects your application, you may submit a letter of appeal."
}]
var stndprocess = [{
	"Slot": "stndprocess",
	"Category": "Standard Process",
	"Token": 4,
	"Data": "Certification Policy and Procedures Manual is firmly adhered to by its 24 Regional Affiliates for the certification of minority-owned businesses.\nCertified MBEs will be recognized by all national corporate members of the NMSDC Network as nationally certified. This means that MBEs will be able to subscribe to a Regional Affiliate and enjoy fee-based, value-added services and support that are unique to their specific market.\nNMSDC’s rigorous certification process requires that minority businesses in our Network are at least 51% minority-owned, operated and controlled. Eligibility is established by conducting a series of screenings, interviews and site visits. This distinguishes NMSDC from other organizations or entities who publish directories allowing for “self-certification” as their standard.\nStringent standardization also identifies bona fide minority businesses, helping purchasing agents report expenditures as well as vendor utilization rates. These procedures help measure overall performance and progress."
}]
var misc = [{
	"Slot": "misc",
	"Category": "Miscellaneous Information",
	"Token": 5,
	"Data": "GMSDC will perform a site visit to review your business premises and conduct a personal interview of the owner(s). This step is performed by a Certification Specialist and the applicant.\nThe Certification Committee meets regularly to review applications for MBE Certification. The Certification Committee must approve the application before it can be submitted to the Board for final approval.\nThe Board will review the Certification Committee's recommendation and make the final decision. If the Board rejects the application, you may submit a letter of appeal. If approved, you will be notified by e-mail and postal mail."
}]

module.exports = {overview, criteria, documentation, appproces, stndprocess, misc}; 